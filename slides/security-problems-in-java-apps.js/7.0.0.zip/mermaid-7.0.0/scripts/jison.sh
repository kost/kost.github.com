node node_modules/jison/lib/cli.js src/diagrams/classDiagram/parser/classDiagram.jison       -o src/diagrams/classDiagram/parser/classDiagram.js
node node_modules/jison/lib/cli.js src/diagrams/sequenceDiagram/parser/sequenceDiagram.jison -o src/diagrams/sequenceDiagram/parser/sequenceDiagram.js
node node_modules/jison/lib/cli.js src/diagrams/example/parser/example.jison                 -o src/diagrams/example/parser/example.js
node node_modules/jison/lib/cli.js src/diagrams/flowchart/parser/flow.jison                  -o src/diagrams/flowchart/parser/flow.js
node node_modules/jison/lib/cli.js src/diagrams/flowchart/parser/dot.jison                   -o src/diagrams/flowchart/parser/dot.js
node node_modules/jison/lib/cli.js src/diagrams/gantt/parser/gantt.jison                     -o src/diagrams/gantt/parser/gantt.js
node node_modules/jison/lib/cli.js src/diagrams/gitGraph/parser/gitGraph.jison               -o src/diagrams/gitGraph/parser/gitGraph.js